create definer = root@localhost view major_view as
select `deyu`.`major`.`majorid`       AS `majorid`,
       `deyu`.`major`.`majorinfo`     AS `majorinfo`,
       `deyu`.`major`.`collegeid`     AS `collegeid`,
       `deyu`.`college`.`collegeinfo` AS `collegeinfo`
from (`deyu`.`major`
         join `deyu`.`college`)
where (`deyu`.`major`.`collegeid` = `deyu`.`college`.`collegeid`);

