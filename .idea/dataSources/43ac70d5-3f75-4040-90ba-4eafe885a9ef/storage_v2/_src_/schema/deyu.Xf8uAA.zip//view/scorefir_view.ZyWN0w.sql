create definer = root@localhost view scorefir_view as
select `deyu`.`scorefirst`.`scoreid`   AS `scoreid`,
       `deyu`.`scorefirst`.`scoreinfo` AS `scoreinfo`,
       `deyu`.`scorefirst`.`collegeid` AS `collegeid`,
       `deyu`.`scorefirst`.`scorebl`   AS `scorebl`,
       `deyu`.`college`.`collegeinfo`  AS `collegeinfo`
from (`deyu`.`college`
         join `deyu`.`scorefirst`)
where (`deyu`.`scorefirst`.`collegeid` = `deyu`.`college`.`collegeid`);

