create definer = root@localhost view user_tea_view as
select `user_view`.`username`         AS `username`,
       `user_view`.`u_id`             AS `u_id`,
       `user_view`.`password`         AS `password`,
       `user_view`.`u_mail`           AS `u_mail`,
       `user_view`.`u_name`           AS `u_name`,
       `user_view`.`u_sex`            AS `u_sex`,
       `user_view`.`u_add`            AS `u_add`,
       `user_view`.`jurisdiction`     AS `jurisdiction`,
       `user_view`.`u_class`          AS `u_class`,
       `user_view`.`stateCode`        AS `stateCode`,
       `user_view`.`info`             AS `info`,
       `user_view`.`user_id`          AS `user_id`,
       `user_view`.`address`          AS `address`,
       `user_view`.`qq`               AS `qq`,
       `user_view`.`vx`               AS `vx`,
       `user_view`.`userinfo`         AS `userinfo`,
       `user_view`.`jurisdictioninfo` AS `jurisdictioninfo`,
       `user_view`.`stateinfo`        AS `stateinfo`,
       `user_view`.`collegeinfo`      AS `collegeinfo`,
       `user_view`.`u_classinfo`      AS `u_classinfo`,
       `user_view`.`openid`           AS `openid`,
       `deyu`.`teacher`.`teacheradd`  AS `teacheradd`,
       `deyu`.`teacher`.`teachersex`  AS `teachersex`,
       `deyu`.`teacher`.`teacherinfo` AS `teacherinfo`,
       `deyu`.`teacher`.`collegeid`   AS `collegeid`,
       `deyu`.`teacher`.`teacherid`   AS `teacherid`
from (`deyu`.`user_view`
         join `deyu`.`teacher`)
where (`user_view`.`u_add` = `deyu`.`teacher`.`teacheradd`);

