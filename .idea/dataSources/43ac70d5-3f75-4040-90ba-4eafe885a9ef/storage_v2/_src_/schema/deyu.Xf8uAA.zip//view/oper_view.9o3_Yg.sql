create definer = root@localhost view oper_view as
select `deyu`.`scoreoperation`.`id`        AS `id`,
       `deyu`.`scoreoperation`.`opname`    AS `opname`,
       `deyu`.`scoreoperation`.`score`     AS `score`,
       `deyu`.`scoreoperation`.`datetime`  AS `datetime`,
       `deyu`.`scoreoperation`.`ip`        AS `ip`,
       `deyu`.`qxinfo`.`jurisdictioninfo`  AS `jurisdictioninfo`,
       `deyu`.`userclass`.`userinfo`       AS `userinfo`,
       `deyu`.`major`.`majorinfo`          AS `majorinfo`,
       `deyu`.`teacher`.`teacherinfo`      AS `teacherinfo`,
       `deyu`.`scoreclass`.`classinfo`     AS `classinfo`,
       `deyu`.`scoresec`.`scoresecinfo`    AS `scoresecinfo`,
       `deyu`.`college`.`collegeinfo`      AS `c_classinfo`,
       `stu_view`.`collegeinfo`            AS `collegeinfo`,
       `deyu`.`operation`.`operationinfo`  AS `operationinfo`,
       `stu_view`.`s_id`                   AS `s_id`,
       `stu_view`.`s_name`                 AS `s_name`,
       `stu_view`.`s_class`                AS `s_class`,
       `stu_view`.`s_sex`                  AS `s_sex`,
       `user_view`.`username`              AS `username`,
       `user_view`.`u_name`                AS `u_name`,
       `stu_view`.`collegeid_0`            AS `college_0`,
       `deyu`.`scoreoperation`.`info`      AS `info`,
       `deyu`.`scoreoperation`.`othername` AS `othername`,
       `deyu`.`scoreoperation`.`othertime` AS `othertime`,
       `deyu`.`scorefirst`.`scoreinfo`     AS `scoreinfo`,
       `deyu`.`test`.`testinfo`            AS `testinfo`
from ((((((((((((`deyu`.`scoreoperation` join `deyu`.`qxinfo` on ((`deyu`.`scoreoperation`.`opjurisdiction` =
                                                                   `deyu`.`qxinfo`.`jurisdiction`))) join `deyu`.`userclass` on ((`deyu`.`scoreoperation`.`opclass` = `deyu`.`userclass`.`userid`))) join `deyu`.`major` on ((`deyu`.`scoreoperation`.`opmajor` = `deyu`.`major`.`majorid`))) join `deyu`.`teacher` on ((`deyu`.`scoreoperation`.`opteacher` = `deyu`.`teacher`.`teacherid`))) join `deyu`.`scoreclass` on ((
        `deyu`.`scoreoperation`.`opscoreclass` = `deyu`.`scoreclass`.`classid`))) join `deyu`.`scoresec` on ((
        (`deyu`.`scoreoperation`.`opscoresec` = `deyu`.`scoresec`.`scoresecid`) and
        (`deyu`.`scoreoperation`.`opscorefir` = `deyu`.`scoresec`.`scorefirid`)))) join `deyu`.`stu_view` on ((`deyu`.`scoreoperation`.`stuid` = `stu_view`.`s_id`))) join `deyu`.`college` on ((`deyu`.`scoreoperation`.`opclassinfo` = `deyu`.`college`.`collegeid`))) join `deyu`.`operation` on ((`deyu`.`scoreoperation`.`opstate` = `deyu`.`operation`.`operationid`))) join `deyu`.`user_view` on ((`deyu`.`scoreoperation`.`opusername` = `user_view`.`username`))) join `deyu`.`scorefirst` on ((`deyu`.`scoreoperation`.`opscorefir` = `deyu`.`scorefirst`.`scoreid`)))
         join `deyu`.`test` on ((`deyu`.`scoreoperation`.`otherstate` = `deyu`.`test`.`testid`)));

