create definer = root@localhost view u_colle_view as
select `deyu`.`user`.`u_id`             AS `u_id`,
       `deyu`.`user`.`username`         AS `username`,
       `deyu`.`user`.`password`         AS `password`,
       `deyu`.`user`.`u_mail`           AS `u_mail`,
       `deyu`.`user`.`u_name`           AS `u_name`,
       `deyu`.`user`.`u_sex`            AS `u_sex`,
       `deyu`.`user`.`u_add`            AS `u_add`,
       `deyu`.`user`.`u_class`          AS `u_class`,
       `deyu`.`user`.`u_classinfo`      AS `u_classinfo`,
       `deyu`.`user`.`jurisdiction`     AS `jurisdiction`,
       `deyu`.`user`.`jurisdictioninfo` AS `jurisdictioninfo`,
       `deyu`.`user`.`stateCode`        AS `stateCode`,
       `deyu`.`user`.`info`             AS `info`,
       `deyu`.`user`.`user_id`          AS `user_id`,
       `deyu`.`user`.`address`          AS `address`,
       `deyu`.`user`.`qq`               AS `qq`,
       `deyu`.`user`.`vx`               AS `vx`,
       `deyu`.`user`.`del`              AS `del`,
       `deyu`.`user`.`openid`           AS `openid`,
       `deyu`.`user`.`apartmentid`      AS `apartmentid`,
       `deyu`.`college`.`collegeinfo`   AS `collegeinfo`,
       `deyu`.`college`.`userclass`     AS `userclass`
from (`deyu`.`user`
         join `deyu`.`college` on ((`deyu`.`user`.`u_classinfo` = `deyu`.`college`.`collegeid`)));

