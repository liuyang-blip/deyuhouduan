create definer = root@localhost view teacher_view as
select `deyu`.`teacher`.`teacherid`   AS `teacherid`,
       `deyu`.`teacher`.`teacherinfo` AS `teacherinfo`,
       `deyu`.`teacher`.`collegeid`   AS `collegeid`,
       `deyu`.`college`.`collegeinfo` AS `collegeinfo`,
       `deyu`.`teacher`.`teacheradd`  AS `teacheradd`,
       `deyu`.`teacher`.`teachersex`  AS `teachersex`
from (`deyu`.`teacher`
         join `deyu`.`college`)
where (`deyu`.`teacher`.`collegeid` = `deyu`.`college`.`collegeid`);

